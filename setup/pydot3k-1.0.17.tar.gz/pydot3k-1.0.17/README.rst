pydot - Python interface to Graphviz's Dot language
Ero Carrera (c) 2004-2007
ero@dkbza.org

Updated for Python 3

This code is distributed under the MIT license.

Requirements:
-------------

pyparsing: pydot requires the pyparsing module in order to be
	able to load DOT files.

GraphViz:  is needed in order to render the graphs into any of
	the plethora of output formats supported.

Installation:
-------------

Should suffice with doing:

 python setup.py install

Needless to say, no installation is needed just to use the module. A mere:

 import pydot

should do it, provided that the directory containing the modules is on Python
module search path.

